/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Cristhian
 */
    public class Administrativo extends Assistente {
    // Construtor
    public Administrativo(String nome, String matricula) {
        super(nome, matricula);
    }
}



    

