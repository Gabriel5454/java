/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Admin
 */
public class Novo extends TipoImovel {
    
    private static final double Valor = 1000.00;
    
    @Override
    public double calcularValor(){
        return Valor;
    }
    
}
