/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pessoa;

/**
 *
 * @author Cristhian
 */
public class ClasseSocial {
    
    protected String nome;
    

    public ClasseSocial(String nome) {
        this.nome = nome;
        
    }

    public void mostrarInfo() {
        System.out.println("Nome: " + nome);
       
    }
}
    

