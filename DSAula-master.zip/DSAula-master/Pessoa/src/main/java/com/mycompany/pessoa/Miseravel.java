/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pessoa;

/**
 *
 * @author Cristhian
 */
public class Miseravel extends ClasseSocial {
    public Miseravel(String nome) {
        super(nome);
    }

    public void mendigar() {
        System.out.println(nome + " está mendigando!");
    }

    
}
